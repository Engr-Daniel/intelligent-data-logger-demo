# Exploratory timing reproducibility supplement

This is an overlay for https://github.com/Engr-Daniel/intelligent-data-logger-demo
(original benchmark release b45331e). Extract into a checkout of that repository,
install its Python dependencies, then follow docs/DETECTION_DELAY_GUIDE.md.
The original frozen benchmark in that repository is required for comparison.

Verify the supplied archive:
python scripts/verify_detection_delay.py reports/research/20261006T022136185304Z_detection_delay

To rerun, use python scripts/analyze_detection_delay.py. It creates a fresh archive
and does not replace the supplied one. No API credentials or paid calls are needed.

The analysis is exploratory, specified after exposure to proposed timing claims.
It uses synthetic installations and unchanged policy thresholds, not field data.
Read the protocol for reference dates, missing detections, phases and persistence.
Raw evidence and an independently checked interpretation are both included.

FILES_SHA256.json gives SHA-256 digests of every supplied source/evidence file.
